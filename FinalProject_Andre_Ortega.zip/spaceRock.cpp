/************************************************
 * Author:	Andre Ortega
 * Date:	12/9/2019
 * Description: 
 ***********************************************/


#include "spaceRock.hpp"

RockSpace::RockSpace()
{

}

int RockSpace::action()
{
    return 0;
}

char RockSpace::getType()
{
    return 'R';
}