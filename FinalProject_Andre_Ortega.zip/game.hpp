/************************************************
 * Author:	Andre Ortega
 * Date:	12/9/2019
 * Description: Header file for game declaration
 * 		and implementation, which is launched 
 *      from the Game() constructor
 ***********************************************/

#ifndef GAME_HPP
#define GAME_HPP

class Game
{
private:

public:

	Game();

};

#endif