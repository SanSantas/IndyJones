/*******************************************************************
 ** Author:       Andre Ortega
 ** Date:         12/9/2019
 ** Description:  THE GAME executes upon declaration of the class
		from the game class constructor. 
*******************************************************************/

#include "menu.hpp"
#include "game.hpp"

int main()

{
	//Launched from game.cpp from Game() constructor
	Game game;

	return 0;
}